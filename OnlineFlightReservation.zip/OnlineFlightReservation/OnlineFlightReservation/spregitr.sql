use FLIGHT
select * from LoginTable
select * from User_Detail


ALTER PROCEDURE usp_Register
	
	(
	@fname varchar(30),
	@age int,
	@gend varchar(6),@addr varchar(30),@phn varchar(10),@pwd varchar(9),@type varchar(1)='U',@usrnm varchar(20)) 
	
	
AS
	begin
	insert into User_Detail values(@fname,@age,@gend,@addr,@phn,@usrnm)
	
	
	insert into LoginTable values(@pwd,@type,@usrnm)
	end
	
	
	 alter table User_Detail drop column UserName
	  alter table User_Detail add  UserName varchar(20)
	  alter table LoginTable add  UserName varchar(20)