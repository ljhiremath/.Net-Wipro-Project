﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineFlightReservation.Admin
{
    public partial class ViewPassenger : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnDisp_Click(object sender, EventArgs e)
        {
            EntityLayer.FlightSchedule objEntityAdmin = new EntityLayer.FlightSchedule
            {
              FlightId = Convert.ToInt32(ddlFid.SelectedValue),
              Date = Convert.ToDateTime(txtDate.Text)
            };

            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();
           // objDALAdminOperations.ViewPassenger(objEntityAdmin);
           

            Response.Redirect("~/Admin/HomeAdmin.aspx");
        }
    }
}