﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace OnlineFlightReservation.Admin
{
    public partial class ModifyRoute : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
           con.Open();

 string query = "select RouteId from RouteDetails";

 SqlCommand cmd = new SqlCommand(query, con);
 SqlDataReader dr;
 dr = cmd.ExecuteReader();

 if (dr.HasRows)
 {
     while (dr.Read())
     {
         ddlRid.Items.Add(dr[0].ToString());
     }
 }
        }

        protected void btnModify_Click(object sender, EventArgs e)
        {
            EntityLayer.RouteDetails objEntityAdmin = new EntityLayer.RouteDetails
            {
                RouteId = Convert.ToInt32(ddlRid.SelectedItem),
                RouteName = txtRname.Text
            };

            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();
            int result = objDALAdminOperations.ModifyRoute(objEntityAdmin);
            if (result > 1)
            {
                Response.Write("<script>alert('Route Modified successfully')</script>");
            }
            else
            {
                Response.Write("<script>alert('Route not Modified successfully')</script>");

            }

            Response.Redirect("~/Admin/HomeAdmin.aspx");

        }
    }
}