﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace OnlineFlightReservation.Admin
{
    public partial class DeleteRoute : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            con.Open();

            string query = "select RouteId from RouteDetails";

            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    ddlRid.Items.Add(dr[0].ToString());
                }
            }
            con.Close();
        }
        protected void btnModify_Click(object sender, EventArgs e)
        {
            EntityLayer.RouteDetails objEntityAdmin = new EntityLayer.RouteDetails
            {
                RouteId = Convert.ToInt32(ddlRid.SelectedItem),
                Source =txtSrc.Text,
                Destination =txtDest.Text,
                RouteName = txtRname.Text
            };

            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();
            int result = objDALAdminOperations.DeleteRoute(objEntityAdmin);
            if (result > 1)
            {
                Response.Write("<script>alert('Route deleted successfully')</script>");
            }
            else
            {
                Response.Write("<script>alert('Route not deleted ')</script>");

            }

            Response.Redirect("~/Admin/HomeAdmin.aspx");
        }

        protected void ddlRid_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtSrc.ReadOnly = false;
            txtDest.ReadOnly = false;
            txtRname.ReadOnly = false;
        }
    }
}