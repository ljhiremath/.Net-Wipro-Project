﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace OnlineFlightReservation.Admin
{
    public partial class DeleteSchedule : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            con.Open();

            string query = "select FlightId from FlightSchedule";

            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    ddlFid.Items.Add(dr[0].ToString());
                }
            }

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {

            EntityLayer.FlightSchedule objEntityAdmin = new EntityLayer.FlightSchedule
            {
                FlightId = Convert.ToInt32(ddlFid.SelectedItem),
                Date = Convert.ToDateTime(txtDate.Text),
                ClassType = txtType.Text,
                Price = Convert.ToInt32(txtPrice),
                AvailableSeats = Convert.ToInt32(txtSeats),
                TotalCapacity = Convert.ToInt32(txtCapacity),
                DepartureTime = Convert.ToDateTime(txtDeptime)

            };

            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();
            int result = objDALAdminOperations.DeleteSchedule(objEntityAdmin);
            if (result > 1)
            {
                Response.Write("<script>alert('Schedule Deleted successfully')</script>");
            }
            else
            {
                Response.Write("<script>alert('Schedule not Deleted')</script>");

            }

            Response.Redirect("~/Admin/HomeAdmin.aspx");
        }

        protected void ddlFid_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtCapacity.ReadOnly = false;
            txtDate.ReadOnly = false;
            txtDeptime.ReadOnly = false;
            txtPrice.ReadOnly = false;
            txtSeats.ReadOnly = false;
            txtType.ReadOnly = false;
        }
    }
}