﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace OnlineFlightReservation.Admin
{
    public partial class DeleteFlight : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            con.Open();

            string query1 = "select FlightId from FlightDetails";

            SqlCommand cmd1 = new SqlCommand(query1, con);
            SqlDataReader dr1;
            dr1 = cmd1.ExecuteReader();

            if (dr1.HasRows)
            {
                while (dr1.Read())
                {
                    ddlFid.Items.Add(dr1[0].ToString());
                }
            }
 

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            EntityLayer.Flight_Detailtable objEntityAdmin = new EntityLayer.Flight_Detailtable
            {
                RouteId = Convert.ToInt32(txtRid.Text),
                FlightName = txtFname.Text,
                FlightId = Convert.ToInt32(ddlFid.SelectedItem),
                ReservationCapacity = Convert.ToInt32(txtResCap.Text)
            };

            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();
            int result = objDALAdminOperations.DeleteFlight(objEntityAdmin);
            if (result > 1)
            {
                Response.Write("<script>alert('Flight Deleted successfully')</script>");
            }
            else
            {
                Response.Write("<script>alert('Flight not Deleted')</script>");

            }

            Response.Redirect("~/Admin/HomeAdmin.aspx");

        }

        protected void ddlFid_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtFname.ReadOnly = false;
            txtResCap.ReadOnly = false;
            txtRid.ReadOnly = false;
        }
    }
}