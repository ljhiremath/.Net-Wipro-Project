﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DataAccessLayer
{
    public class AdminOperations
    {
        public int AddFlight(EntityLayer.Flight_Detailtable objAdmin)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("usp_AdFlight", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@Fname", SqlDbType.VarChar, 20).Value = objAdmin.FlightName;
            cmd.Parameters.Add("@Capacity", SqlDbType.Int).Value = objAdmin.ReservationCapacity;
            cmd.Parameters.Add("@Rid ", SqlDbType.Int).Value = objAdmin.RouteId;
            con.Open();
            int _rows = cmd.ExecuteNonQuery();
            con.Close();
            return _rows;
        }
        public int AddSchedule(EntityLayer.FlightSchedule objAdmin)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("usp_AdSchedule", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@Fid ", SqlDbType.VarChar, 20).Value = objAdmin.FlightId;
            cmd.Parameters.Add("@date", SqlDbType.Int).Value = objAdmin.Date;
            cmd.Parameters.Add("@seats", SqlDbType.VarChar, 20).Value = objAdmin.AvailableSeats;
            cmd.Parameters.Add("@price", SqlDbType.VarChar, 20).Value = objAdmin.Price;
            cmd.Parameters.Add("@cap", SqlDbType.VarChar, 20).Value = objAdmin.TotalCapacity;
            cmd.Parameters.Add("@Deptime", SqlDbType.VarChar, 20).Value = objAdmin.DepartureTime;
            cmd.Parameters.Add("@type", SqlDbType.VarChar, 20).Value = objAdmin.ClassType;
            con.Open();
            int _rows = cmd.ExecuteNonQuery();
            con.Close();
            return _rows;
        }

        public int AddRoute(EntityLayer.RouteDetails objAdmin)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("usp_AdRoute", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@src", SqlDbType.VarChar, 20).Value = objAdmin.Source;
            cmd.Parameters.Add("@dst", SqlDbType.VarChar, 20).Value = objAdmin.Destination;
            cmd.Parameters.Add("@Rname", SqlDbType.VarChar, 10).Value = objAdmin.RouteName;
            con.Open();
            int _rows = cmd.ExecuteNonQuery();
            con.Close();
            return _rows;
        }

     
        //public int ViewPassenger(EntityLayer.PassengerDetails objAdmin, EntityLayer.FlightSchedule objAdminFs, EntityLayer.ReservationDetails objAdminRd)
        //{
        //    SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

        //    SqlCommand cmd = new SqlCommand("usp_ViewPassgr", con);
        //    cmd.CommandType = CommandType.StoredProcedure;

        //    cmd.Parameters.Add("@Fid", SqlDbType.Int).Value = objAdminFs.FlightId ;
        //    cmd.Parameters.Add("@dt", SqlDbType.Date).Value = objAdminFs.Date;
           
        //    con.Open();
        //    int _rows = cmd.ExecuteNonQuery();
        //    con.Close();
        //    return _rows;
        //}

        public int ModifyRoute(EntityLayer.RouteDetails objAdmin)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("usp_ModRoute", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Rid", SqlDbType.Int).Value = objAdmin.RouteId;
            cmd.Parameters.Add("@Rname", SqlDbType.VarChar, 10).Value = objAdmin.RouteName;
            con.Open();
            int _rows = cmd.ExecuteNonQuery();
            con.Close();
            return _rows;
        }
        public int ModifyFlight(EntityLayer.Flight_Detailtable objAdmin)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("usp_ModFlight", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Rid", SqlDbType.Int).Value = objAdmin.RouteId;
            cmd.Parameters.Add("@Fid", SqlDbType.Int).Value = objAdmin.FlightId;
            cmd.Parameters.Add("@Fname", SqlDbType.VarChar,15).Value = objAdmin.FlightName;
            cmd.Parameters.Add("@capacity", SqlDbType.Int).Value = objAdmin.ReservationCapacity;
            con.Open();
            int _rows = cmd.ExecuteNonQuery();
            con.Close();
            return _rows;
        }
        public int ModifySchedule(EntityLayer.FlightSchedule objAdmin)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("usp_ModSchedule", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@dt", SqlDbType.Date).Value = objAdmin.Date;
            cmd.Parameters.Add("@Fid", SqlDbType.Int).Value = objAdmin.FlightId;
            cmd.Parameters.Add("@seats", SqlDbType.Int).Value = objAdmin.AvailableSeats;
            cmd.Parameters.Add("@price", SqlDbType.Money).Value = objAdmin.Price;
            cmd.Parameters.Add("@capacity", SqlDbType.Int).Value = objAdmin.TotalCapacity;
            cmd.Parameters.Add("@deptime", SqlDbType.Time).Value = objAdmin.DepartureTime;
            cmd.Parameters.Add("@type", SqlDbType.VarChar,10).Value = objAdmin.ClassType;
             con.Open();
            int _rows = cmd.ExecuteNonQuery();
            con.Close();
            return _rows;
        }

        public int DeleteRoute(EntityLayer.RouteDetails objAdmin)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("usp_DelRoute", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Rid", SqlDbType.Int).Value = objAdmin.RouteId;
            con.Open();
            int _rows = cmd.ExecuteNonQuery();
            con.Close();
            return _rows;
        }
        public int DeleteFlight(EntityLayer.FlightDetails objAdmin)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("usp_DelFlight", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Fid", SqlDbType.Int).Value = objAdmin.FlightId;
            con.Open();
            int _rows = cmd.ExecuteNonQuery();
            con.Close();
            return _rows;
        }
        public int DeleteSchedule(EntityLayer.FlightDetails objAdmin)
        {
            SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

            SqlCommand cmd = new SqlCommand("usp_DelFlight", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@Fid", SqlDbType.Int).Value = objAdmin.FlightId;
            con.Open();
            int _rows = cmd.ExecuteNonQuery();
            con.Close();
            return _rows;
        }
   
    }
}
