﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;



namespace DataAccessLayer
{
   public  class UserOperations
   {
       public int Registration(EntityLayer.User_Detail objUser, EntityLayer.LoginTable objLogin)
       {
           SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
           
          SqlCommand cmd = new SqlCommand("usp_Register", con);
          cmd.CommandType = CommandType.StoredProcedure;
          
          cmd.Parameters.Add("@fname", SqlDbType.VarChar,20).Value = objUser.FirstName;
          cmd.Parameters.Add("@age", SqlDbType.Int).Value = objUser.Age;
          cmd.Parameters.Add("@gend", SqlDbType.VarChar,20).Value = objUser.Gender;
          cmd.Parameters.Add("@addr", SqlDbType.VarChar,20).Value = objUser.Address;
          cmd.Parameters.Add("@phn", SqlDbType.VarChar,20).Value = objUser.Phoneno;
          cmd.Parameters.Add("@pwd", SqlDbType.VarChar,20).Value = objLogin.Password;
          cmd.Parameters.Add("@type", SqlDbType.VarChar, 20).Value = objLogin.Usertype;
        cmd.Parameters.Add("@usrnm", SqlDbType.VarChar, 20).Value = objLogin.UserName;


          con.Open();
         int _rows= cmd.ExecuteNonQuery();
         con.Close();
         return _rows;
       }
       
    }
}
