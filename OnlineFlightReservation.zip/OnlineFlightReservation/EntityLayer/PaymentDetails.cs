﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityLayer
{
   public class PaymentDetails
    {
        public int PaymentId { get; set; }
        public int ReservationId { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime PaymentDate { get; set; }
    }
}
