﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityLayer
{
   public class Flight_Detailtable
    {
        public int FlightId { get; set; }
        public string FlightName { get; set; }
        public int ReservationCapacity { get; set; }
        public int RouteId { get; set; } 
   }
}
