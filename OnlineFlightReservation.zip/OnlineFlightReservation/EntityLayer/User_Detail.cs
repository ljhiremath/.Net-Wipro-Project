﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityLayer
{
   public class User_Detail
    {
       
        public int UserId { get; set; }
        public string FirstName { get; set; }
        public int Age { get; set; }
        public string  Gender{ get; set; }
        public string Address { get; set; }
        public string Phoneno { get; set; }
        public string UserName { get; set; }
    }
}


