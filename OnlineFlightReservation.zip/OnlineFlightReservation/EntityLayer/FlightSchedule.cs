﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityLayer
{
   public class FlightSchedule
    {
        public int FlightId { get; set; }
        public DateTime Date { get; set; }
        public string ClassType { get; set; }
        public int AvailableSeats { get; set; }
        public decimal Price { get; set; }
        public int TotalCapacity { get; set; }
        public string DepartureTime { get; set; }
        

    }
}
