﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityLayer
{
   public class FlightClass
    {
        public int ClassId { get; set; }
        public string ClassName { get; set; }
    }
}
