﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityLayer
{
   public class PassengerDetails
    {
        public int ReservationId { get; set; }
        public string PassengerName { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public int SeatNo { get; set; }
    }
}
