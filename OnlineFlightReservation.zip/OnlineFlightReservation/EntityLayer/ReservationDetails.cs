﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EntityLayer
{
   public class ReservationDetails
    {
        public int ReservationId { get; set; }
        public int UserId { get; set; }
        public int FlightId { get; set; }
        public DateTime DateofJourney { get; set; }
        public int No_of_Seats { get; set; }
        public int ClassId { get; set; }




    }
}
