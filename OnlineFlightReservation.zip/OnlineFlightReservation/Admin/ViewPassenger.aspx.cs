﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using DataAccessLayer;

namespace OnlineFlightReservation.Admin
{
    public partial class ViewPassenger : System.Web.UI.Page
    {
        ConnectionManager objcon = new ConnectionManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
                SqlConnection cn = objcon.OpenConnectionString();
                try
                {

                string query = "select FlightId from Flight_Detailtable";

                SqlCommand cmd = new SqlCommand(query, cn);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        ddlFid.Items.Add(dr[0].ToString());
                    }
                }
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    if (cn.State != ConnectionState.Closed)
                        cn.Close();

                }
            }
        }

        protected void btnDisp_Click(object sender, EventArgs e)
        {
            //EntityLayer.ReservationDetails objAdminRd = new EntityLayer.ReservationDetails();

            //objAdminRd.FlightId = Convert.ToInt32(ddlFid.SelectedValue);
            //objAdminRd.DateofJourney = Convert.ToDateTime(txtDate.Text);

            //EntityLayer.PassengerDetails objUserPd = new EntityLayer.PassengerDetails();

            //DataAccessLayer.AdminOperations oobjAdmin = new DataAccessLayer.AdminOperations();
            //oobjAdmin.ViewPassenger(objAdminRd, objUserPd);

            //SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
             SqlConnection cn = objcon.OpenConnectionString();
                try
                {
            SqlDataAdapter da = new SqlDataAdapter("select RD.ReservationId,RD.FlightId,RD.DateofJourney,PD.PassengerName,PD.Age,PD.Gender,PD.SeatNo from ReservationDetails RD join PassengerDetails PD on PD.ReservationId = RD.ReservationId where (RD.FlightId = " + ddlFid.SelectedValue + " and RD.DateofJourney ='" + txtDate.Text + "')", cn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gvPsgr.DataSource = ds;
            gvPsgr.DataBind();
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    if (cn.State != ConnectionState.Closed)
                        cn.Close();

                }
             
            
            // Response.Redirect("~/Admin/HomeAdmin.aspx");
        }
    }
}