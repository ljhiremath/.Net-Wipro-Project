﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using DataAccessLayer;
using System.Data;
namespace OnlineFlightReservation.Admin
{
    public partial class DeleteSchedule : System.Web.UI.Page
    {
        ConnectionManager objcon = new ConnectionManager();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
                SqlConnection cn = objcon.OpenConnectionString();
                try
                {

                    string query = "select FlightId from FlightSchedule";

                    SqlCommand cmd = new SqlCommand(query, cn);
                    SqlDataReader dr;
                    dr = cmd.ExecuteReader();

                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            ddlFid.Items.Add(dr[0].ToString());
                        }
                    }
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    if (cn.State != ConnectionState.Closed)
                        cn.Close();

                }

            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            EntityLayer.FlightSchedule objEntityAdmin = new EntityLayer.FlightSchedule
            {
                FlightId = Convert.ToInt32(ddlFid.SelectedItem.Value),

            };


            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();
            int result = objDALAdminOperations.DeleteSchedule(objEntityAdmin);
            if (result > 0)
            {
                Response.Write("<script>alert('Schedule Deleted successfully')</script>");
            }
            else
            {
                Response.Write("<script>alert('Schedule not Deleted')</script>");

            }

            //Response.Redirect("~/Admin/HomeAdmin.aspx");
        }

        protected void ddlFid_SelectedIndexChanged(object sender, EventArgs e)
        {
            EntityLayer.FlightSchedule objEntityAdmin = new EntityLayer.FlightSchedule();

            objEntityAdmin.FlightId = Convert.ToInt32(ddlFid.SelectedValue);
            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();
            objDALAdminOperations.DisplaySchedule(objEntityAdmin);
            txtDate.Text = objEntityAdmin.Date.ToLongDateString();
            txtDeptime.Text = objEntityAdmin.DepartureTime.ToString();
            txtCapacity.Text = objEntityAdmin.TotalCapacity.ToString();
            txtPrice.Text = objEntityAdmin.Price.ToString();
            txtSeats.Text = objEntityAdmin.AvailableSeats.ToString();
            txtType.Text = objEntityAdmin.ClassType;

            txtCapacity.ReadOnly = false;
            txtDate.ReadOnly = false;
            txtDeptime.ReadOnly = false;
            txtPrice.ReadOnly = false;
            txtSeats.ReadOnly = false;
            txtType.ReadOnly = false;
        }
    }
}