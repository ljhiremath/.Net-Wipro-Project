﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using DataAccessLayer;
using System.Data;

namespace OnlineFlightReservation.Admin
{
    public partial class ModifySchedule : System.Web.UI.Page
    {ConnectionManager objcon = new ConnectionManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
             SqlConnection cn = objcon.OpenConnectionString();
                try
                {

            string query = "select FlightId from FlightSchedule";

            SqlCommand cmd = new SqlCommand(query, cn);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();

            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    ddlFid.Items.Add(dr[0].ToString());
                }
            }
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    if (cn.State != ConnectionState.Closed)
                        cn.Close();

                }

        }

        protected void btnModify_Click(object sender, EventArgs e)
        {
            EntityLayer.FlightSchedule objEntityAdmin = new EntityLayer.FlightSchedule
            {
                FlightId = Convert.ToInt32(ddlFid.SelectedItem.Value),
                Date = Convert.ToDateTime(txtDate.Text),
                ClassType = ddlType.SelectedItem.Value,
                Price = Convert.ToInt32(txtPrice.Text),
                AvailableSeats =  Convert.ToInt32(txtSeats.Text),
                TotalCapacity = Convert.ToInt32(txtCapacity.Text),
               DepartureTime = Convert.ToString(txtDeptime.Text)               
            };

            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();
            int result = objDALAdminOperations.ModifySchedule(objEntityAdmin);
            if (result > 0)
            {
                Response.Write("<script>alert('Schedule Modified successfully')</script>");
            }
            else
            {
                Response.Write("<script>alert('Schedule not Modified successfully')</script>");

            }

           // Response.Redirect("~/Admin/HomeAdmin.aspx");
        }
    }
}