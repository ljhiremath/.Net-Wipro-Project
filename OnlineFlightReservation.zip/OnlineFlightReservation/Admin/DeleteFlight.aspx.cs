﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using DataAccessLayer;
using System.Data;

namespace OnlineFlightReservation.Admin
{
    public partial class DeleteFlight : System.Web.UI.Page
    {
        ConnectionManager objcon = new ConnectionManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
                SqlConnection cn = objcon.OpenConnectionString();
                try
                {
                    string query1 = "select FlightId from Flight_Detailtable";

                    SqlCommand cmd1 = new SqlCommand(query1, cn);
                    SqlDataReader dr1;
                    dr1 = cmd1.ExecuteReader();

                    if (dr1.HasRows)
                    {
                        while (dr1.Read())
                        {
                            ddlFid.Items.Add(dr1[0].ToString());
                        }
                    }
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    if (cn.State != ConnectionState.Closed)
                        cn.Close();

                }

            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            EntityLayer.Flight_Detailtable objEntityAdmin = new EntityLayer.Flight_Detailtable
            {


                FlightId = Convert.ToInt32(ddlFid.SelectedItem.Value),

            };

            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();
            int result = objDALAdminOperations.DeleteFlight(objEntityAdmin);
            if (result > 0)
            {
                Response.Write("<script>alert('Flight Deleted successfully')</script>");
            }
            else
            {
                Response.Write("<script>alert('Flight not Deleted')</script>");

            }

            //Response.Redirect("~/Admin/HomeAdmin.aspx");

        }

        protected void ddlFid_SelectedIndexChanged(object sender, EventArgs e)
        {
            EntityLayer.Flight_Detailtable objEntityAdmin = new EntityLayer.Flight_Detailtable();
            objEntityAdmin.FlightId = Convert.ToInt32(ddlFid.SelectedValue);
            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();
            objDALAdminOperations.DisplayFlight(objEntityAdmin);

            txtFname.Text = objEntityAdmin.FlightName;
            txtResCap.Text = objEntityAdmin.ReservationCapacity.ToString();
            txtRid.Text = objEntityAdmin.RouteId.ToString();

            txtFname.ReadOnly = false;
            txtResCap.ReadOnly = false;
            txtRid.ReadOnly = false;
        }
    }
}