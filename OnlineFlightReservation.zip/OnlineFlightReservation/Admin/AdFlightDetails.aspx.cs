﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace OnlineFlightReservation.Admin
{
    public partial class AdFlightDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void btnADD_Click(object sender, EventArgs e)
        {
             EntityLayer.Flight_Detailtable objEntityAdmin = new EntityLayer.Flight_Detailtable
            {
                FlightName = ddlFname.SelectedValue,
                 ReservationCapacity = Convert.ToInt32(txtResCapacity.Text),
                 RouteId = Convert.ToInt32(txtRid.Text)
            };
           
            DataAccessLayer.AdminOperations objDALAdminOperations=new DataAccessLayer.AdminOperations();
            int result=  objDALAdminOperations.AddFlight(objEntityAdmin);
            if(result>0)
            { Response.Write("<script>alert('Flight Added successfully')</script>");
            }
            else
            { Response.Write("<script>alert('Flight not Added successfully')</script>");

            }
           
            //Response.Redirect("~/Admin/HomeAdmin.aspx");
        }
        }
    }
