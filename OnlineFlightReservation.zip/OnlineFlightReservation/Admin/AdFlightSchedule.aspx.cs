﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineFlightReservation.Admin
{
    public partial class AdFlightSchedule : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            EntityLayer.FlightSchedule objEntityAdmin = new EntityLayer.FlightSchedule
            {
                FlightId = Convert.ToInt32(txtFid.Text),
                Date = Convert.ToDateTime(txtDate.Text),
                AvailableSeats = Convert.ToInt32(txtAvseats.Text),
                Price = Convert.ToInt32(txtPrice.Text),
                TotalCapacity = Convert.ToInt32(txtTcap.Text),
                DepartureTime = Convert.ToString(txtDepTime.Text),
                ClassType = txtCid.Text
            
            };
           
            DataAccessLayer.AdminOperations objDALAdminOperations=new DataAccessLayer.AdminOperations();
            int result=  objDALAdminOperations.AddSchedule(objEntityAdmin);
            if(result>0)
            { Response.Write("<script>alert('Flight Schedule Added successfully')</script>");
            }
            else
            {
                Response.Write("<script>alert('Flight Schedule not Added successfully')</script>");

            }
           
           // Response.Redirect("~/Admin/HomeAdmin.aspx");
        
        }
    }
}