﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineFlightReservation.Admin
{
    public partial class AdRoute : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            EntityLayer.RouteDetails objEntityAdmin = new EntityLayer.RouteDetails();
            
            
              
            objEntityAdmin.Source = txtSrc.Text;
                objEntityAdmin.Destination = txtDest.Text;
                objEntityAdmin.RouteName = txtRname.Text;

           

            DataAccessLayer.AdminOperations objDALAdminOperations = new DataAccessLayer.AdminOperations();

            int result = objDALAdminOperations.AddRoute(objEntityAdmin);
            if (result > 0)
            {
                Response.Write("<script>alert('Flight Route Added successfully')</script>");
            }
            else
            {
                Response.Write("<script>alert('Flight Route not Added successfully')</script>");

            }

            //Response.Redirect("~/Admin/HomeAdmin.aspx");
        }

       
    }
}