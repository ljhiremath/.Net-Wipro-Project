﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using System.Data;


namespace OnlineFlightReservation
{
    /// <summary>
    /// Summary description for AddrouteWebservice
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class AddrouteWebservice : System.Web.Services.WebService
    {

        
        //[WebMethod]
        //  public int AddRoute(EntityLayer.RouteDetails objAdmin)
        //{
        //    SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");

        //    SqlCommand cmd = new SqlCommand("usp_AdRoute", con);
        //    cmd.CommandType = CommandType.StoredProcedure;

        //    cmd.Parameters.Add("@src", SqlDbType.VarChar, 20).Value = objAdmin.Source;
        //    cmd.Parameters.Add("@dst", SqlDbType.VarChar, 20).Value = objAdmin.Destination;
        //    cmd.Parameters.Add("@Rname", SqlDbType.VarChar, 10).Value = objAdmin.RouteName;
        //    con.Open();
        //    int _rows = cmd.ExecuteNonQuery();
        //    con.Close();
        //    return _rows;
        //}
        [WebMethod]

        public string Msg()
        {
           
           return ("Welcome admin");
        }

    }
}
