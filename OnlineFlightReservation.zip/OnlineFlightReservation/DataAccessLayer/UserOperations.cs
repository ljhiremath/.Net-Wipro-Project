﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;



namespace DataAccessLayer
{
    public class UserOperations
    {
        ConnectionManager objcon = new ConnectionManager();

        public int Registration(EntityLayer.User_Detail objUser, EntityLayer.LoginTable objLogin)
        {
            int _rows;
            // SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {
                SqlCommand cmd = new SqlCommand("usp_Register", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@fname", SqlDbType.VarChar, 20).Value = objUser.FirstName;
                cmd.Parameters.Add("@age", SqlDbType.Int).Value = objUser.Age;
                cmd.Parameters.Add("@gend", SqlDbType.VarChar, 20).Value = objUser.Gender;
                cmd.Parameters.Add("@addr", SqlDbType.VarChar, 20).Value = objUser.Address;
                cmd.Parameters.Add("@phn", SqlDbType.VarChar, 20).Value = objUser.Phoneno;
                cmd.Parameters.Add("@pwd", SqlDbType.VarChar, 20).Value = objLogin.Password;
                cmd.Parameters.Add("@type", SqlDbType.VarChar, 20).Value = objLogin.Usertype;
                cmd.Parameters.Add("@usrnm", SqlDbType.VarChar, 20).Value = objLogin.UserName;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;
        }
        public int TicketReservation(EntityLayer.ReservationDetails objUser)
        {
            int num;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {
                SqlCommand cmd = new SqlCommand("usp_UserReservation", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@usrid", SqlDbType.Int).Value = objUser.UserId;
                cmd.Parameters.Add("@Fid ", SqlDbType.Int).Value = objUser.FlightId;
                cmd.Parameters.Add("@datejrny", SqlDbType.Date).Value = objUser.DateofJourney;
                cmd.Parameters.Add("@seats", SqlDbType.Int).Value = objUser.No_of_Seats;
                cmd.Parameters.Add("@Clsid", SqlDbType.Int).Value = objUser.ClassId;

                cmd.ExecuteNonQuery();


                SqlCommand cmdd = new SqlCommand("select max(ReservationId) from ReservationDetails", cn);
                num = Convert.ToInt32(cmdd.ExecuteScalar());
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }
            return num;

        }
        public int bookTicketMultiple(EntityLayer.PassengerDetails objUserPsgr, EntityLayer.ReservationDetails objUserReserve)
        {
            int _rows;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_MultiplePsgr", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@fid", SqlDbType.Int).Value = objUserReserve.FlightId;
                cmd.Parameters.Add("@psrname", SqlDbType.VarChar, 20).Value = objUserPsgr.PassengerName;
                cmd.Parameters.Add("@age", SqlDbType.Int).Value = objUserPsgr.Age;
                cmd.Parameters.Add("@gndr", SqlDbType.VarChar, 6).Value = objUserPsgr.Gender;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;
        }

        public DataSet DisplayFlightGridView(EntityLayer.RouteDetails objUserRD, EntityLayer.FlightSchedule objUserFS)
        {  //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            DataSet ds = new DataSet();
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_DispFlight", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@src", SqlDbType.VarChar, 12).Value = objUserRD.Source;
                cmd.Parameters.Add("@dest", SqlDbType.VarChar, 12).Value = objUserRD.Destination;
                cmd.Parameters.Add("@datjrny", SqlDbType.Date).Value = objUserFS.Date;
                SqlDataAdapter da = new SqlDataAdapter(cmd);

                da.Fill(ds);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return ds;
        }

        public decimal Price(EntityLayer.FlightSchedule objUserFS, EntityLayer.FlightClass objUserReserve)
        {
            int TicketPrice;
            // SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_CalcPrice", cn);
                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.Add("@Fid ", SqlDbType.Int).Value = objUserFS.FlightId;

                cmd.Parameters.Add("@Cid ", SqlDbType.Int).Value = objUserReserve.ClassId;

                TicketPrice = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return TicketPrice;
        }
        public string Login(EntityLayer.LoginTable objUser)
        {
            string usertype;
            // SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_Login", cn);
                cmd.CommandType = CommandType.StoredProcedure;


                cmd.Parameters.Add("@usrname", SqlDbType.VarChar, 12).Value = objUser.UserName;

                cmd.Parameters.Add("@pwd", SqlDbType.VarChar, 9).Value = objUser.Password;

                usertype = cmd.ExecuteScalar() as string;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return usertype;
        }
        public int paymentvalidation(EntityLayer.CreditCardDetails objUser)
        {
            int _rows;
            //  SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd2 = new SqlCommand("usp_ChkCreditcard", cn);
                cmd2.CommandType = CommandType.StoredProcedure;

                cmd2.Parameters.Add("@cardno", SqlDbType.VarChar, 20).Value = objUser.CardNo;
                cmd2.Parameters.Add("@cvv", SqlDbType.Int).Value = objUser.CVV;
                cmd2.Parameters.Add("@vfrm", SqlDbType.Date).Value = objUser.ValidFrom;
                cmd2.Parameters.Add("@vto", SqlDbType.Date).Value = objUser.ValidTo;


                _rows = (int)cmd2.ExecuteScalar();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;
        }
        public int payment(EntityLayer.PaymentDetails objPayments, EntityLayer.CreditCardDetails objUser)
        {
            int _rows;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd1 = new SqlCommand("usp_subbalance", cn);
                cmd1.CommandType = CommandType.StoredProcedure;

                cmd1.Parameters.Add("@cardno", SqlDbType.VarChar, 20).Value = objUser.CardNo;
                cmd1.Parameters.Add("@cvv", SqlDbType.Int).Value = objUser.CVV;
                cmd1.Parameters.Add("@vfrm", SqlDbType.Date).Value = objUser.ValidFrom;
                cmd1.Parameters.Add("@vto", SqlDbType.Date).Value = objUser.ValidTo;
                cmd1.Parameters.Add("@price", SqlDbType.Decimal).Value = objPayments.TotalAmount;


                _rows = cmd1.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;

        }

        public int GetUserid(EntityLayer.LoginTable objLogin)
        {
            int _id;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("useridGet", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Username", SqlDbType.VarChar, 20).Value = objLogin.UserName;
                cmd.Parameters.Add("@password", SqlDbType.VarChar, 20).Value = objLogin.Password;


                _id = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _id;
        }
        public int GetClass(EntityLayer.FlightClass objclass, EntityLayer.FlightSchedule objSchdl)
        {
            int _Cid;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_Classid", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@fid", SqlDbType.Int).Value = objSchdl.FlightId;
                cmd.Parameters.Add("@dt", SqlDbType.Date).Value = objSchdl.Date;
                cmd.Parameters.Add("@cid", SqlDbType.Int).Value = objclass.ClassId;



                _Cid = Convert.ToInt32(cmd.ExecuteNonQuery());
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _Cid;
        }
        public void GetTypeFlight(EntityLayer.Flight_Detailtable objFlt, EntityLayer.ReservationDetails objrsrv)
        {
            SqlDataReader dr = null;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {
                SqlCommand cmd = new SqlCommand("select FD.FlightName FROM Flight_Detailtable FD JOIN ReservationDetails RD ON FD.FlightId = RD.FlightId  WHERE (RD.FlightId =" + objrsrv.FlightId + " and RD.ReservationId=" + objrsrv.ReservationId + ")", cn);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();

                    objFlt.FlightName = dr.GetString(0);

                }

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if ((dr != null) && !dr.IsClosed)
                    dr.Close();
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

        }
        public int CancelTicket(EntityLayer.ReservationDetails objresrv)
        {
            int _id;
            // SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_Cancl", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Rid", SqlDbType.Int).Value = objresrv.ReservationId;

                _id = Convert.ToInt32(cmd.ExecuteNonQuery());
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _id;
        }
    }
}
