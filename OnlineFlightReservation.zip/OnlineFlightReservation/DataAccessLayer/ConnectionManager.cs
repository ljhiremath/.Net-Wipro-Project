﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using EntityLayer;

namespace DataAccessLayer
{
   public class ConnectionManager:IDisposable
   {
       const string ConnectionKey = "FLIGHTConnectionString";
            SqlConnection _objConnection;
            string _strConnectionString;

            public ConnectionManager()
            {
                _strConnectionString = ConfigurationManager.ConnectionStrings[ConnectionManager.ConnectionKey].ConnectionString;
                _objConnection = new SqlConnection(_strConnectionString);
            }

            ~ConnectionManager()
            {

            }

            public SqlConnection OpenConnectionString()
            {
                _objConnection.Open();
                return _objConnection;
            }


            public void Dispose()
            {
                _objConnection.Close();
                _objConnection.Dispose();
            }

            protected void Dispose(bool blnIsDisposing)
            {

            }


        }
    }

