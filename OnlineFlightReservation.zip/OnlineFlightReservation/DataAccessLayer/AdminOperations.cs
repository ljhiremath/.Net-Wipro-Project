﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
namespace DataAccessLayer
{
    public class AdminOperations
    {
        ConnectionManager objcon = new ConnectionManager();

        public int AddFlight(EntityLayer.Flight_Detailtable objAdmin)
        {
            int _rows;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {
                SqlCommand cmd = new SqlCommand("usp_AdFlight", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@Fname", SqlDbType.VarChar, 20).Value = objAdmin.FlightName;
                cmd.Parameters.Add("@Capacity", SqlDbType.Int).Value = objAdmin.ReservationCapacity;
                cmd.Parameters.Add("@Rid ", SqlDbType.Int).Value = objAdmin.RouteId;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }
            return _rows;
        }
        public int AddSchedule(EntityLayer.FlightSchedule objAdmin)
        {
            int _rows;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_AdSchedule", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@Fid ", SqlDbType.VarChar, 20).Value = objAdmin.FlightId;
                cmd.Parameters.Add("@date", SqlDbType.Date).Value = objAdmin.Date;
                cmd.Parameters.Add("@seats", SqlDbType.Int).Value = objAdmin.AvailableSeats;
                cmd.Parameters.Add("@price", SqlDbType.Money).Value = objAdmin.Price;
                cmd.Parameters.Add("@cap", SqlDbType.Int).Value = objAdmin.TotalCapacity;
                cmd.Parameters.Add("@Deptime", SqlDbType.VarChar, 15).Value = objAdmin.DepartureTime;
                cmd.Parameters.Add("@type", SqlDbType.VarChar, 20).Value = objAdmin.ClassType;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }
            return _rows;
        }

        public int AddRoute(EntityLayer.RouteDetails objAdmin)
        {
            int _rows;
            // SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_AdRoute", cn);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@src", SqlDbType.VarChar, 20).Value = objAdmin.Source;
                cmd.Parameters.Add("@dst", SqlDbType.VarChar, 20).Value = objAdmin.Destination;
                cmd.Parameters.Add("@Rname", SqlDbType.VarChar, 10).Value = objAdmin.RouteName;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;
        }


        public void ViewPassenger(EntityLayer.ReservationDetails objAdminRd, EntityLayer.PassengerDetails objUserPd)
        {
            SqlDataReader dr;

            SqlConnection cn = objcon.OpenConnectionString();
            try
            {
                string str = "select RD.ReservationId,RD.FlightId,RD.DateofJourney,PD.PassengerName,PD.Age,PD.Gender,PD.SeatNo from ReservationDetails RD join PassengerDetails PD on PD.ReservationId = RD.ReservationId where (RD.FlightId = " + objAdminRd.FlightId + " and RD.DateofJourney =" + objAdminRd.DateofJourney + ")";
                SqlCommand cmd = new SqlCommand(str, cn);


                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    objAdminRd.ReservationId = dr.GetInt32(0);
                    objAdminRd.FlightId = dr.GetInt32(1);
                    objAdminRd.DateofJourney = dr.GetDateTime(2);
                    objUserPd.PassengerName = dr.GetString(3);
                    objUserPd.Age = dr.GetInt32(4);
                    objUserPd.Gender = dr.GetString(5);
                    objUserPd.SeatNo = dr.GetInt32(6);
                }
                dr.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
               // if (( dr != null) && !dr.IsClosed)
                  //  dr.Close();
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

        }

        public int ModifyRoute(EntityLayer.RouteDetails objAdmin)
        {
            int _rows;
            //   SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_ModRoute", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Rid", SqlDbType.Int).Value = objAdmin.RouteId;
                cmd.Parameters.Add("@Rname", SqlDbType.VarChar, 10).Value = objAdmin.RouteName;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;
        }
        public int ModifyFlight(EntityLayer.Flight_Detailtable objAdmin)
        {
            int _rows;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_ModFlight", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Rid", SqlDbType.Int).Value = objAdmin.RouteId;
                cmd.Parameters.Add("@Fid", SqlDbType.Int).Value = objAdmin.FlightId;
                cmd.Parameters.Add("@Fname", SqlDbType.VarChar, 15).Value = objAdmin.FlightName;
                cmd.Parameters.Add("@capacity", SqlDbType.Int).Value = objAdmin.ReservationCapacity;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;
        }
        public int ModifySchedule(EntityLayer.FlightSchedule objAdmin)
        {
            int _rows;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_ModSchedule", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@dt", SqlDbType.Date).Value = objAdmin.Date;
                cmd.Parameters.Add("@Fid", SqlDbType.Int).Value = objAdmin.FlightId;
                cmd.Parameters.Add("@seats", SqlDbType.Int).Value = objAdmin.AvailableSeats;
                cmd.Parameters.Add("@price", SqlDbType.Money).Value = objAdmin.Price;
                cmd.Parameters.Add("@capacity", SqlDbType.Int).Value = objAdmin.TotalCapacity;
                cmd.Parameters.Add("@deptime", SqlDbType.VarChar, 15).Value = objAdmin.DepartureTime;
                cmd.Parameters.Add("@type", SqlDbType.VarChar, 10).Value = objAdmin.ClassType;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;
        }

        public int DeleteRoute(EntityLayer.RouteDetails objAdmin)
        {
            int _rows;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_DelRoute", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Rid", SqlDbType.Int).Value = objAdmin.RouteId;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;
        }
        public int DeleteFlight(EntityLayer.Flight_Detailtable objAdmin)
        {
            int _rows;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_DelFlight", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Fid", SqlDbType.Int).Value = objAdmin.FlightId;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;
        }
        public int DeleteSchedule(EntityLayer.FlightSchedule objAdmin)
        {
            int _rows;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                SqlCommand cmd = new SqlCommand("usp_DelSchedule", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Fid", SqlDbType.Int).Value = objAdmin.FlightId;

                _rows = cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

            return _rows;
        }
        public void DisplayRoute(EntityLayer.RouteDetails objAdmin)
        {
            SqlDataReader dr = null;
            //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                string qry = "select Source,Destination,RouteName from RouteDetails where RouteID=" + objAdmin.RouteId;

                SqlCommand cmd = new SqlCommand(qry, cn);

                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    objAdmin.Source = dr.GetString(0);
                    objAdmin.Destination = dr.GetString(1);
                    objAdmin.RouteName = dr.GetString(2);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if ((dr != null) && !dr.IsClosed)
                    dr.Close();

                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

        }

        public void DisplayFlight(EntityLayer.Flight_Detailtable objAdmin)
        {
            SqlDataReader dr = null ;
            // SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                string qry = "select FlightName,ReservationCapacity,RouteId from Flight_Detailtable where FlightId=" + objAdmin.FlightId;
                SqlCommand cmd = new SqlCommand(qry, cn);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    objAdmin.RouteId = dr.GetInt32(2);
                    objAdmin.FlightName = dr.GetString(0);
                    objAdmin.ReservationCapacity = dr.GetInt32(1);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if ((dr != null) && !dr.IsClosed)
                    dr.Close();

                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }
        }

        public void DisplaySchedule(EntityLayer.FlightSchedule objAdmin)
        {
            SqlDataReader dr = null;
            //          SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
            SqlConnection cn = objcon.OpenConnectionString();
            try
            {

                string qry = "select Date,AvailableSeats,Price,TotalCapacity,ClassType,DepartureTime from FlightSchedule where FlightId =" + objAdmin.FlightId;

                SqlCommand cmd = new SqlCommand(qry, cn);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    objAdmin.Date = dr.GetDateTime(0);
                    objAdmin.DepartureTime = dr.GetString(5);
                    objAdmin.ClassType = dr.GetString(4);
                    objAdmin.AvailableSeats = dr.GetInt32(1);
                    objAdmin.Price = dr.GetDecimal(2);
                    objAdmin.TotalCapacity = dr.GetInt32(3);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                if ((dr != null) && !dr.IsClosed)
                    dr.Close();

                if (cn.State != ConnectionState.Closed)
                    cn.Close();

            }

        }
    }
}
