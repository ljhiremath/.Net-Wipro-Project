﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
namespace OnlineFlightReservation.User
{
    public partial class FlightDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            }

        protected void btnBook_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            EntityLayer.RouteDetails objEntityUserRD = new EntityLayer.RouteDetails
            {
                Source = ddlSrc.SelectedValue,
                Destination = ddlDest.SelectedValue

            };
            EntityLayer.FlightSchedule objEntityUserFS = new EntityLayer.FlightSchedule
            {
               Date = Convert.ToDateTime(txtDate.Text)

            };
            DataAccessLayer.UserOperations objDALUserOperations = new DataAccessLayer.UserOperations();
             ds = objDALUserOperations.DisplayFlightGridView(objEntityUserRD, objEntityUserFS);

           
            DataList1.DataSource = ds.Tables[0];
            DataList1.DataBind();
            //if (true)
            //{
            //    Response.Redirect("~/User/TicketReservation.aspx");
            //}

            Session["Source"] = ddlSrc.SelectedItem.Value;
            Session["Destination"] = ddlDest.SelectedItem.Value;
            Session["Date"] = Convert.ToDateTime(txtDate.Text);
            //Session["FlightId"] = ddlFid.SelectedItem.Value;
        }

       

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
          
            Session["FlightId"] = e.CommandArgument;
            Response.Redirect("~/User/TicketReservation.aspx");
        }

      

       
    }
}