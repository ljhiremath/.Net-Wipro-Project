﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineFlightReservation.User
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            EntityLayer.User_Detail objEntityUser = new EntityLayer.User_Detail
            {
                FirstName=txtFN.Text,
                Age=Int32.Parse(txtAge.Text),
                Gender=txtGndr.Text,
                Address=txtAddrss.Text,
                Phoneno=txtPhN.Text,
            UserName=txtUN.Text                   
            
            };
            EntityLayer.LoginTable objEntityUserLogin = new EntityLayer.LoginTable
            {
                Password=txtPwd.Text,
                Usertype="U",
            UserName=txtUN.Text          
         
            
            };
            DataAccessLayer.UserOperations objDALUserOperations=new DataAccessLayer.UserOperations();
            int result=  objDALUserOperations.Registration(objEntityUser,objEntityUserLogin);
            if(result>1)
            { Response.Write("<script>alert('Registration  successful')</script>");
            }
            else
            { Response.Write("<script>alert('Registration not successful')</script>");

            }
            //Session["UserId"] = ddlSrc.SelectedItem.Value;
           // Response.Redirect("~/User/DefaultUser.aspx");
        }
    }
}