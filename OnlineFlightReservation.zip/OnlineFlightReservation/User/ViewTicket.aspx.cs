﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using DataAccessLayer;

namespace OnlineFlightReservation.User
{
    public partial class ViewTicket : System.Web.UI.Page
    {ConnectionManager objcon = new ConnectionManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            lblTAmnt.Text = Convert.ToString(Session["Price"]);
            lblNoseats.Text = Convert.ToString(Session["No_of_Seats"]);
            
              lblDoj.Text = Session["Date"].ToString();
            lblSrc.Text= Session["Source"].ToString();
            lblDest.Text = Session["Destination"].ToString();
            lblFid.Text = Session["FlightId"].ToString();
           lblResId.Text= Convert.ToString(Session["ReservationId"]);
           lblCtype.Text = Convert.ToString(Session["ClassType"]);

           
           EntityLayer.Flight_Detailtable objFlt = new EntityLayer.Flight_Detailtable();
           EntityLayer.ReservationDetails objRsrv = new EntityLayer.ReservationDetails();


           objRsrv.FlightId = Convert.ToInt32(lblFid.Text);
           
           objRsrv.ReservationId = Convert.ToInt32(lblResId.Text);
           
            DataAccessLayer.UserOperations objDALUserOperations = new DataAccessLayer.UserOperations();

             objDALUserOperations.GetTypeFlight(objFlt,objRsrv);
           
             
               lblFn.Text = objFlt.FlightName;

               //SqlConnection cn = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
               SqlConnection cn = objcon.OpenConnectionString();
               try
               {  
            SqlDataAdapter da = new SqlDataAdapter("select PD.PassengerName,PD.Age,PD.Gender from PassengerDetails PD JOIN ReservationDetails RD on RD.ReservationId= PD.ReservationId where RD.ReservationId=" + lblResId.Text, cn);
               DataSet ds = new DataSet();
               da.Fill(ds);
               GridView1.DataSource = ds;
               GridView1.DataBind();
               //if (Convert.ToInt32(lblNoseats.Text) == 1)
               //{
               //    Panel1.Visible = true;
               //    Panel2.Visible = false;
               //    Panel4.Visible = false;
               //    Panel5.Visible = false;
               //    lblPsgr1.Text = Session["PassengerName"].ToString();
               //    lblAge1.Text = Session["Age"].ToString();
               //    lblGen1.Text = Session["Gender"].ToString();
               //}
               //else if (Convert.ToInt32(lblNoseats.Text) == 2)
               //{
               //    Panel1.Visible = true;
               //    Panel2.Visible = true;
               //    Panel4.Visible = false;
               //    Panel5.Visible = false;
               //    lblPsgr1.Text = Session["PassengerName"].ToString();
               //    lblAge1.Text = Session["Age"].ToString();
               //    lblGen1.Text = Session["Gender"].ToString();

               //    lblPsgr2.Text = Session["PassengerName"].ToString();
               //    lblAge2.Text = Session["Age"].ToString();
               //    lblGen2.Text = Session["Gender"].ToString();
               //}
               //else if (Convert.ToInt32(lblNoseats.Text) == 3)
               //{
               //    Panel1.Visible = true;
               //    Panel2.Visible = true;
               //    Panel4.Visible = true;
               //    Panel5.Visible = false;

               //    lblPsgr1.Text = Session["PassengerName"].ToString();
               //    lblAge1.Text = Session["Age"].ToString();
               //    lblGen1.Text = Session["Gender"].ToString();

               //    lblPsgr2.Text = Session["PassengerName"].ToString();
               //    lblAge2.Text = Session["Age"].ToString();
               //    lblGen2.Text = Session["Gender"].ToString();

               //    lblPsgr3.Text = Session["PassengerName"].ToString();
               //    lblAge3.Text = Session["Age"].ToString();
               //    lblGen3.Text = Session["Gender"].ToString();

               //}
               //else if (Convert.ToInt32(lblNoseats.Text) == 4)
               //{
               //    Panel1.Visible = true;
               //    Panel2.Visible = true;
               //    Panel4.Visible = true;
               //    Panel5.Visible = true;

               //    lblPsgr1.Text = Session["PassengerName"].ToString();
               //    lblAge1.Text = Session["Age"].ToString();
               //    lblGen1.Text = Session["Gender"].ToString();

               //    lblPsgr2.Text = Session["PassengerName"].ToString();
               //    lblAge2.Text = Session["Age"].ToString();
               //    lblGen2.Text = Session["Gender"].ToString();

               //    lblPsgr3.Text = Session["PassengerName"].ToString();
               //    lblAge3.Text = Session["Age"].ToString();
               //    lblGen3.Text = Session["Gender"].ToString();

               //    lblPsgr4.Text = Session["PassengerName"].ToString();
               //    lblAge4.Text = Session["Age"].ToString();
               //    lblGen4.Text = Session["Gender"].ToString();
               //}
               }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    if (cn.State != ConnectionState.Closed)
                        cn.Close();

                }

                 
              
              

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/User/CancelTicket.aspx");

        }

        protected void btnPrint_Click(object sender, EventArgs e)
        {
            Response.Write("<script>window.print()</script>");

        }
    }
}