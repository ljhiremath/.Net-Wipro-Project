﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineFlightReservation.User
{
    public partial class HomeUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string s = "";
            WcfSr.Service1 objref = new WcfSr.Service1();
           s= objref.Msg();
           Response.Write(s);
        }
    }
}