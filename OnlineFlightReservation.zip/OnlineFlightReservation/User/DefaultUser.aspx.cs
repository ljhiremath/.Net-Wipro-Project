﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineFlightReservation.User
{
    public partial class DefaultUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            EntityLayer.LoginTable objUserLogin = new EntityLayer.LoginTable();
            {
                objUserLogin.UserName = txtUserName.Text;
                objUserLogin.Password = txtPwd.Text;
            }
            //Response.Redirect("~/User/HomeUser.aspx");

            DataAccessLayer.UserOperations objDALUserOperations = new DataAccessLayer.UserOperations();
            int userid =objDALUserOperations.GetUserid(objUserLogin);
            string usertype = objDALUserOperations.Login(objUserLogin);
            if ((usertype != null && usertype.ToUpper() == "A"))
            {
                Session["Usertype"] = usertype;
                Session["UserName"] = objUserLogin.UserName;

                Session["Password"] = objUserLogin.Password;
                Session["UserId"] = userid;
                Response.Redirect("~/Admin/HomeAdmin.aspx");

            }
            else if ((usertype != null && usertype.ToUpper() == "U"))
            
            {
                Session["Usertype"] = usertype;
                Session["UserName"] = objUserLogin.UserName;

                Session["Password"] = objUserLogin.Password;
                Session["UserId"] = userid;
                Response.Redirect("~/User/HomeUser.aspx");
            }
            else
            {
                Response.Write("<script>alert('Please enter a correct UserName & password')</script>");
            }
        }
    }
}