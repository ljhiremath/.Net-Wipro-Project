﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineFlightReservation.User
{
    public partial class Payment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblTAmnt.Text = Convert.ToString(Session["Price"]);
            Calendar1.Visible=false;
            Calendar2.Visible = false;
           // txtVtoDate.Text = Calendar2.SelectedDate.ToLongDateString();
        }

        protected void btnPayment_Click(object sender, EventArgs e)
        {
            EntityLayer.PaymentDetails objpayments = new EntityLayer.PaymentDetails();
            {
                objpayments.TotalAmount = Convert.ToDecimal(Session["Price"]);

                objpayments.ReservationId = Convert.ToInt32(Session["ReservationId"]);

            }

            EntityLayer.CreditCardDetails objcreditcard = new EntityLayer.CreditCardDetails();
            {
                objcreditcard.CardNo = (txtCnum.Text);
                objcreditcard.CVV = Convert.ToInt32(txtCvv.Text);
                objcreditcard.ValidFrom = Convert.ToDateTime(txtVfrom.Text);
                objcreditcard.ValidTo = Convert.ToDateTime(txtVtoDate.Text);
            }

            DataAccessLayer.UserOperations objpayment = new DataAccessLayer.UserOperations();

            int creditflag = objpayment.paymentvalidation(objcreditcard);
            if (creditflag > 0)
            {
                int paymentsuccessflag = objpayment.payment(objpayments, objcreditcard);
                if (paymentsuccessflag > 0)
                {

                    string script = "<script>";
                    script += "alert('PAYMENT SUCCESSFULL');";

                    //script += "window.location='Eticket.aspx'"; 
                    Response.Redirect("~/User/ViewTicket.aspx");
                    script += "</script>";

                    Response.Write(script);
                }
                else
                {
                    Response.Write("<script>alert('TRANSACTION CANCELLED')</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('WRONG CREDENTIALS')</script>");
            }

        }

        protected void Calendar2_SelectDate(object sender, EventArgs e)
        {
            txtVtoDate.Text = Calendar2.SelectedDate.ToShortDateString();
            
        }

        protected void Calendar1_SelectDate(object sender, EventArgs e)
        {
            txtVfrom.Text = Calendar1.SelectedDate.ToShortDateString();
            
        }
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {Calendar1.Visible = true;
            
        }

        

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
    Calendar2.Visible = true;
            
        }
         
            
    }
}