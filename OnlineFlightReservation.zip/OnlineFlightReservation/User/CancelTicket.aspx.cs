﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlineFlightReservation.User
{
    public partial class CancelTicket : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {  // int ID= Convert.ToInt32(txtResId.Text);

            EntityLayer.ReservationDetails objresrv = new EntityLayer.ReservationDetails();
            objresrv.ReservationId = Convert.ToInt32(txtResId.Text);

            DataAccessLayer.UserOperations objUsr = new DataAccessLayer.UserOperations();
            int rw = objUsr.CancelTicket(objresrv);
            if (rw > 0)
            {
                Response.Write("<script>alert('Ticket Cancelled')</script>");
            }
            else
            {
                Response.Write("<script>alert('Ticket not Cancelled')</script>");
            }
       
        }
    }
}