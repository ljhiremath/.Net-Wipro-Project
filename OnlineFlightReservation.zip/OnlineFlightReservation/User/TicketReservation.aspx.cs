﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using DataAccessLayer;
using System.Data;

namespace OnlineFlightReservation.User
{
    public partial class TicketReservation : System.Web.UI.Page
    {
        ConnectionManager objcon = new ConnectionManager();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblFid.Text = Session["FlightId"].ToString();

                lblDOJ.Text = Session["Date"].ToString();
                lblSrc.Text = Session["Source"].ToString();
                lblDest.Text = Session["Destination"].ToString();
                Panel1.Visible = false;
                Panel2.Visible = false;
                Panel3.Visible = false;
                Panel4.Visible = false;
            }

            if (!IsPostBack)
            {
                //SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=FLIGHT;Integrated Security=True");
                  SqlConnection cn = objcon.OpenConnectionString();
                try
                {

                string query = "select FC.ClassId from FlightClass FC join FlightSchedule FS on FS.ClassType = FC.ClassType where ( FlightId ="+ lblFid.Text  +" and Date = '"+ lblDOJ.Text + "')";

                SqlCommand cmd = new SqlCommand(query, cn);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        ddlClassId.Items.Add(dr[0].ToString());
                    }
                }
                }
                catch (SqlException ex)
                {
                    throw ex;
                }
                finally
                {
                    if (cn.State != ConnectionState.Closed)
                        cn.Close();

                }

            }
           
                
            }
                 
   

        protected void btnBook_Click(object sender, EventArgs e)
        {
            Session["No_of_Seats"]=Convert.ToInt32(ddlNoseats.SelectedValue);
            
            EntityLayer.FlightSchedule objFSchdl = new EntityLayer.FlightSchedule();
            EntityLayer.FlightClass objFcls = new EntityLayer.FlightClass();
            EntityLayer.ReservationDetails objEntityUser = new EntityLayer.ReservationDetails();
           
            objEntityUser.UserId = (int)Session["UserId"];
            objEntityUser.FlightId = Convert.ToInt32(lblFid.Text);
            objEntityUser.DateofJourney = (DateTime)Session["Date"];
            objEntityUser.No_of_Seats = Convert.ToInt32(ddlNoseats.SelectedValue);
            objEntityUser.ClassId = Convert.ToInt32(ddlClassId.SelectedValue);

            if (Convert.ToInt32(ddlClassId.SelectedValue) == 101)
                Session["ClassType"] = "Business";
            else if (Convert.ToInt32(ddlClassId.SelectedValue) == 102)
                Session["ClassType"] = "Economy";
            else if (Convert.ToInt32(ddlClassId.SelectedValue) == 103)
                Session["ClassType"] = "Premiere";

            objFcls.ClassId = Convert.ToInt32(ddlClassId.SelectedValue);
             objFSchdl.Date = (DateTime)Session["Date"];
             objFSchdl.FlightId = Convert.ToInt32(lblFid.Text);
            
            DataAccessLayer.UserOperations objDALUserOperations = new DataAccessLayer.UserOperations();
            int verify = objDALUserOperations.GetClass(objFcls, objFSchdl);
            int flag= objDALUserOperations.TicketReservation(objEntityUser);
            Session["ReservationId"] = flag;
              
            if(ddlNoseats.SelectedItem.Text == "1")
                {
                    EntityLayer.PassengerDetails objPsgr = new EntityLayer.PassengerDetails();
                    objPsgr.PassengerName = txtPsgr1.Text;
                    Session["PassengerName"]= txtPsgr1.Text;
                    objPsgr.Gender = ddlG1.SelectedValue;
                    Session["Gender"] = ddlG1.SelectedValue;
                    objPsgr.Age = Convert.ToInt32(txtAge1.Text);
                    Session["Age"] = Convert.ToInt32(txtAge1.Text);
                 objDALUserOperations.bookTicketMultiple(objPsgr, objEntityUser);

                }
                else if (ddlNoseats.SelectedItem.Text == "2")
                {
                    EntityLayer.PassengerDetails objPsgr1 = new EntityLayer.PassengerDetails();
                    objPsgr1.PassengerName = txtPsgr1.Text;
                    Session["PassengerName"] = txtPsgr1.Text;
                    objPsgr1.Gender = ddlG1.SelectedValue;
                    Session["Gender"] = ddlG1.SelectedValue;
                    objPsgr1.Age = Convert.ToInt32(txtAge1.Text);
                    Session["Age"] = Convert.ToInt32(txtAge1.Text);
                     objDALUserOperations.bookTicketMultiple(objPsgr1, objEntityUser);
                    EntityLayer.PassengerDetails objPsgr2 = new EntityLayer.PassengerDetails();
                    objPsgr2.PassengerName = txtPsgr2.Text;
                    Session["PassengerName"] = txtPsgr2.Text;
                    objPsgr2.Gender = ddlG2.SelectedValue;
                    Session["Gender"] = ddlG2.SelectedValue;
                    objPsgr2.Age = Convert.ToInt32(txtAge2.Text);
                    Session["Age"] = Convert.ToInt32(txtAge2.Text);
                     objDALUserOperations.bookTicketMultiple(objPsgr2, objEntityUser);
                }
                else if (ddlNoseats.SelectedItem.Text == "3")
                {
                    EntityLayer.PassengerDetails objPsgr1 = new EntityLayer.PassengerDetails();
                    objPsgr1.PassengerName = txtPsgr1.Text;
                    objPsgr1.Gender = ddlG1.SelectedValue;
                    objPsgr1.Age = Convert.ToInt32(txtAge1.Text);
                     objDALUserOperations.bookTicketMultiple(objPsgr1, objEntityUser);
                    EntityLayer.PassengerDetails objPsgr2 = new EntityLayer.PassengerDetails();
                    objPsgr2.PassengerName = txtPsgr2.Text;
                    objPsgr2.Gender = ddlG2.SelectedValue;
                    objPsgr2.Age = Convert.ToInt32(txtAge2.Text);
                     objDALUserOperations.bookTicketMultiple(objPsgr2, objEntityUser);
                    EntityLayer.PassengerDetails objPsgr3 = new EntityLayer.PassengerDetails();
                    objPsgr3.PassengerName = txtPsgr3.Text;
                    objPsgr3.Gender = ddlG3.SelectedValue;
                    objPsgr3.Age = Convert.ToInt32(txtAge3.Text);
                     objDALUserOperations.bookTicketMultiple(objPsgr3, objEntityUser);
                }
             else if (ddlNoseats.SelectedItem.Text == "4")
                {
                    EntityLayer.PassengerDetails objPsgr1 = new EntityLayer.PassengerDetails();
                    objPsgr1.PassengerName = txtPsgr1.Text;
                    objPsgr1.Gender = ddlG1.SelectedValue;
                    objPsgr1.Age = Convert.ToInt32(txtAge1.Text);
                     objDALUserOperations.bookTicketMultiple(objPsgr1, objEntityUser);
                    EntityLayer.PassengerDetails objPsgr2 = new EntityLayer.PassengerDetails();
                    objPsgr2.PassengerName = txtPsgr2.Text;
                    objPsgr2.Gender = ddlG2.SelectedValue;
                    objPsgr2.Age = Convert.ToInt32(txtAge2.Text);
                     objDALUserOperations.bookTicketMultiple(objPsgr2, objEntityUser);
                    EntityLayer.PassengerDetails objPsgr3 = new EntityLayer.PassengerDetails();
                    objPsgr3.PassengerName = txtPsgr3.Text;
                    objPsgr3.Gender = ddlG3.SelectedValue;
                    objPsgr3.Age = Convert.ToInt32(txtAge3.Text);
                     objDALUserOperations.bookTicketMultiple(objPsgr3, objEntityUser);
                   EntityLayer.PassengerDetails objPsgr4 = new EntityLayer.PassengerDetails();
                    objPsgr4.PassengerName = txtPsgr4.Text;
                    objPsgr4.Gender = ddlG4.SelectedValue;
                    objPsgr4.Age = Convert.ToInt32(txtAge4.Text);
                     objDALUserOperations.bookTicketMultiple(objPsgr4, objEntityUser);
                }
            string script = "<script>";
            script += "alert('Tickets booked Successfully Your Reservation id is : " + flag + "');";
            Response.Redirect("~/User/Payment.aspx");
            script += "</script>";

            Response.Write(script);

            }

           
        
    
      

        protected void ddlNoseats_SelectedIndexChanged(object sender, EventArgs e)
        {
            EntityLayer.FlightClass objcls = new EntityLayer.FlightClass();
            EntityLayer.FlightSchedule objpsgr = new EntityLayer.FlightSchedule();
            objpsgr.FlightId = Convert.ToInt32(lblFid.Text);
                
            EntityLayer.ReservationDetails objReservation = new EntityLayer.ReservationDetails();
            objcls.ClassId = Convert.ToInt32(ddlClassId.SelectedValue);
            objReservation.No_of_Seats = Convert.ToInt32(ddlNoseats.SelectedValue);
            DataAccessLayer.UserOperations objTicketReservation = new DataAccessLayer.UserOperations();
            decimal k = objTicketReservation.Price(objpsgr, objcls);
            int seats = Convert.ToInt32(objReservation.No_of_Seats);
            decimal amnt = k * seats;
            Session["Price"] = amnt;
            if (amnt != 0)
            {
                lblPrice.Text = amnt.ToString();

            }
            else
            {
                Response.Write("<script>alert('No flight available for that class type.')</script>");
                lblPrice.Text = "";

            }
            if (ddlNoseats.SelectedItem.Text == "Select No. of Seats" )
            { 
            }
    else

       {
            if (Convert.ToInt32(ddlNoseats.SelectedItem.Text) == 1)
            {
                Panel1.Visible = true;
                Panel2.Visible = false;
                Panel3.Visible = false;
                Panel4.Visible = false;
            }
            else if (Convert.ToInt32(ddlNoseats.SelectedItem.Text) == 2)
            {
                Panel1.Visible = true;
                Panel2.Visible = true;
                Panel3.Visible = false;
                Panel4.Visible = false;
            }
            else if (Convert.ToInt32(ddlNoseats.SelectedItem.Text) == 3)
            {
                Panel1.Visible = true;
                Panel2.Visible = true;
                Panel3.Visible = true;
                Panel4.Visible = false;
            }
            else if (Convert.ToInt32(ddlNoseats.SelectedItem.Text) == 4)
            {
                Panel1.Visible = true;
                Panel2.Visible = true;
                Panel3.Visible = true;
                Panel4.Visible = true;
            }
      }
     
}
    protected void ddlClassId_SelectedIndexChanged(object sender, EventArgs e)
        {
      if ( (ddlClassId.SelectedItem.Text)== "Select Class")
      {  Response.Write("<script>alert('Please choose a  class.')</script>");
      }
      else
      {
                  
            }

        }

    protected void ddlG1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
        }
        }



        
    
